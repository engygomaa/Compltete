package Hooks;
import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.Login.LoginPage;

import java.time.Duration;

import static org.junit.Assert.assertTrue;

public class CommonSteps {
  private WebDriver driver = Hooks.getDriver();
  private LoginPage loginPage = new LoginPage(driver);

  @Given("the user is on the login page")
  public void open_login_page() {
    driver.get("https://app.skeyerp.com/auth/Dev/login");
  }

  @When("the user logs in using test data")
  public void loginFromTestData() {
    loginPage.loginFromJson();
  }

  @Then("the user should be redirected to the dashboard")
  public void verify_dashboard() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("InputSearch")));
      String currentUrl = driver.getCurrentUrl();
      assertTrue("Expected redirect to dashboard but was: " + currentUrl, currentUrl.equals("https://app.skeyerp.com/dashboard"));


    // TODO: assert current URL or element
  }
}
