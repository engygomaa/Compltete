package Datautilites;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import javax.swing.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Field;

public class Utility {
    private static final String Test_Data_Path="src/test/resources/Testdata";
    public static String getjsondata(String filename,String field)throws FileNotFoundException
    {
        FileReader reader=new FileReader(Test_Data_Path+filename+".json");
        JsonElement JSONElement= JsonParser.parseReader(reader);
       return JSONElement.getAsJsonObject().get(field).getAsString();
    }
}
