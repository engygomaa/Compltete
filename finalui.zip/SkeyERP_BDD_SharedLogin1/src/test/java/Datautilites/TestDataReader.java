
package Datautilites;

import java.io.FileReader;
import java.io.Reader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class TestDataReader {
    public static JSONObject readJson(String path) {
        JSONParser parser = new JSONParser();
        try (Reader reader = new FileReader(path)) {
            return (JSONObject) parser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
