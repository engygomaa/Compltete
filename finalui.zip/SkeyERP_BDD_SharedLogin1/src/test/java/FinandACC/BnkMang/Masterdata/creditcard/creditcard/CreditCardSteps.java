package FinandACC.BnkMang.Masterdata.creditcard.creditcard;
import Hooks.Hooks;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pages.creditcard.CreditCardPage;

import Datautilites.TestDataReader;
import org.json.simple.JSONObject;

public class CreditCardSteps {

  // 👇 added to close popup if visible during navigation
  
  private WebDriver driver = Hooks.getDriver();
  private CreditCardPage page = new CreditCardPage(driver);


  @When("the user clicks on Finance and Accounting")
  public void step1() {
    page.clickFinance();
  }

  @And("the user clicks on Banking Management")
  public void step2() {
    page.clickBankingManagement();
  }

  @And("the user clicks on Master Data")
  public void step3() {
    page.clickMasterData();
  }

  @And("the user clicks on Credit Card Type")
  public void step4() {
    page.clickCreditCardType();
  }

  @And("the user clicks on Add")
  public void step5() {
    page.clickAddButton();
  }

  @And("the user enters valid card details from file")
  public void step6() {
    JSONObject data = TestDataReader.readJson("src/test/resources/Testdata/credit_card_test_data.json");
    if (data != null) {
      page.enterCardDetails(data);
    }
  }

  @And("clicks on the Save button")
  public void step7() {
    page.clicksaveCard();
  }

  @Then("the credit card should be added")
  public void verify_card() {

  }

  @When("I have a credit card with the name from the test data")
  public void step10() {
    
    page.closeNotifcationIfVisible();
JSONObject data1 = TestDataReader.readJson("src/test/resources/Testdata/credit_card_inactive.json");
    if (data1 != null) {
      String cardName = (String) data1.get("Type_Name");
      page.doubleClickOnCardByName(cardName);
    }
  }

  @And("I click the Inactive button")
  public void step11() {
    page.clickInactiveButton();
  }

  @And("I deactivate the card switch before entering the deactivation reason")
  public void stepDeactivateSwitch() {
    page.deactivateSwitch(); // تحريك السويتش
  }

  @And("I enter the deactivation reason from test data")
  public void step12() {
    JSONObject data1 = TestDataReader.readJson("src/test/resources/Testdata/credit_card_inactive.json");
    if (data1 != null) {
      String reason = (String) data1.get("Reason");
      page.enterDeactivationReason(reason); // ثم تدخل السبب
    }
  }

  @And("I confirm the deactivation")
  public void step13() {
    page.clickSaveDeactivation();
  }


  @Then("The credit card should be marked as inactive")
  public void step14() {

    JSONObject data = TestDataReader.readJson("src/test/resources/Testdata/credit_card_inactive.json");
    if (data != null) {
      String cardName = (String) data.get("Type_Name");
      page.verifyCardIsInactive(cardName);
    }
  }
  @When("I have a credit card with the name from the test data1")
  public void step15() {
    page.closeNotifcationIfVisible();
    JSONObject data1 = TestDataReader.readJson("src/test/resources/Testdata/Credit_card_test_data.json");
    if (data1 != null) {
      String cardName = (String) data1.get("Type_Name");
      page.doubleClickOnCardByName2(cardName);
    }
  }
  @And("The user click on update")
  public void step16() {
    page.clickupdButton();
  }
  @And("clear any control and  Change any control in test data")
  public void clearandchange() {
    JSONObject data = TestDataReader.readJson("src/test/resources/Testdata/Credit_card_upd.json");
    if (data != null) {
      page.clearandchange(data);
    }
  }
  @And("Click on save")
  public void step17() {
    page.clicksaveCard1();
  }
  @Then("The credit card should be update")
  public void clicksaveCardupd() {

  }
 @When("I have a credit card with the name from the test data2")
 public void step18() {
   page.closeNotifcationIfVisible();
   JSONObject data1 = TestDataReader.readJson("src/test/resources/Testdata/credit_card_delete.json");
   if (data1 != null) {
     String cardName = (String) data1.get("Type_Name");
     page.doubleClickOnCardByName3(cardName);
   }
 }
  @And("The user click on delete")
   public void step19() {
    page.clickdelButton();
  }

 @And("The user click on confirm")
 public void step20() {
   page.clickconfirmButton();
 }
  @Then("The credit card should be Deleted")
  public void verify_card_Del() {

  }
}