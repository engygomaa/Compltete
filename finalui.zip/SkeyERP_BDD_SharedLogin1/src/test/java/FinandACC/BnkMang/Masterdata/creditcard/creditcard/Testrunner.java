package FinandACC.BnkMang.Masterdata.creditcard.creditcard;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

import org.junit.runner.RunWith;
@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"FinandACC.BnkMang.Masterdata.creditcard.creditcard","Hooks"},
        plugin = {"pretty", "io.qameta.allure.cucumber7jvm.AllureCu" +
                "cumber7Jvm"},
        tags = "@Smokecreditcard",
        monochrome = true

)
public class Testrunner {



}
