package pages.Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;



import Datautilites.TestDataReader;
import org.json.simple.JSONObject;

public class LoginPage {
  WebDriver driver;
  WebDriverWait wait;

  public LoginPage(WebDriver driver) {
    this.driver = driver;
    wait = new WebDriverWait(driver, Duration.ofSeconds(10));
  }

  public void loginFromJson() {
    JSONObject data = TestDataReader.readJson("src/test/resources/Testdata/login_test_data.json");
    if (data != null) {
      login(data.get("username").toString(), data.get("password").toString());
    }
  }

  public void login(String username, String password) {
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("usrCode"))).sendKeys(username);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("usrPswrd"))).sendKeys(password);
    driver.findElement(By.xpath("//button[@type='submit']")).click();

  
}}
