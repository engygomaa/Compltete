package pages.creditcard;




import org.json.simple.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.time.Duration;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class CreditCardPage {
  WebDriver driver;

  public CreditCardPage(WebDriver driver) {
    this.driver = driver;
  }

  public void clickFinance() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3000));
    WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//span[text()='الحسابات والمالية']")
    ));
    el.click();

  }

  public void clickBankingManagement() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3000));
    WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//span[contains(text(),'إدارة البنوك')])[1]")
    ));
    el.click(); // أو أي action تانية

  }

  public void clickMasterData() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3000));
    WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//span[contains(text(),'البيانات الأساسية')])[3]")
    ));
    el.click(); // أو أي عملية أخرى

  }

  public void clickCreditCardType() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3000));
    WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//span[contains(text(),'أنواع بطائق الائتمان')])[1]")
    ));
    el.click();


  }

  public void clickAddButton() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));
    WebElement plusIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//i[@class='fal fa-plus fa-lg grid-add'])[1]")
    ));
    plusIcon.click();

  }

  public void enterCardDetails(JSONObject data) {

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));

    WebElement inputField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@placeholder='اسم النوع'])[1]")));
    inputField.sendKeys((String) data.get("Type_Name"));

    WebElement inputField2 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='الترتيب']")));
    inputField2.sendKeys((String) data.get("Order"));

    WebElement inputField3 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@placeholder='البريد الإلكتروني'])[1]")));
    inputField3.sendKeys((String) data.get("E-mail"));

  }

  public void clicksaveCard() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//button[@title='حفظ'])[1]")
    ));
    saveBtn.click();


    WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//div[@aria-label='تمت العملية بنجاح']")
    ));
    String actualMsg = message.getAttribute("aria-label");
    assertEquals("تمت العملية بنجاح", actualMsg);

  }

  public void doubleClickOnCardByName(String cardName) {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    boolean found = false;
    int maxPages = 20;
    int currentTry = 0;

    while (currentTry < maxPages) {
      currentTry++;

      try {
        closeNotifcationIfVisible();

        WebElement cardRow = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//td[@role='gridcell' and normalize-space()='" + cardName + "']")));

        new Actions(driver).doubleClick(cardRow).perform();
        System.out.println("✅ Found and double-clicked on card: " + cardName);
        found = true;
        break;

      } catch (TimeoutException e) {
        try {
          closeNotifcationIfVisible();

          WebElement currentPage = driver.findElement(By.xpath("//a[contains(@class,'e-currentitem')]"));
          int currentPageNumber = Integer.parseInt(currentPage.getText());
          int nextPageNumber = currentPageNumber + 1;

          List<WebElement> nextPageButtons = driver.findElements(
                  By.xpath("//a[contains(@aria-label,'Page " + nextPageNumber + "')]"));

          if (nextPageButtons.isEmpty()) {
            System.out.println("❌ زر الصفحة التالية غير موجود. توقف.");
            break;
          }

          WebElement nextPageBtn = nextPageButtons.get(0);

          ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPageBtn);
          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageBtn);

          Thread.sleep(2000);

        } catch (Exception ex) {
          System.out.println("❌ Reached last page or couldn't click on page number. Card not found: " + cardName);
          break;
        }
      }
    }

    if (!found) {
      System.out.println("🔍 Card not found in any page: " + cardName);
    }
  }


  public void clickInactiveButton() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(500));
    WebElement inactiveButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//i[@class='fad fa-lock-alt'])[1]")
    ));
    inactiveButton.click();
  }

  public void deactivateSwitch() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2000));

    // انتظار ظهور السويتش ثم تحريكه
    WebElement switchElement = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//label[@class='switch-box-slider'])[1]")  // أو استخدم الـ XPath المناسب
    ));

    if (!switchElement.isSelected()) {
      switchElement.click();  // تحريك السويتش إلى وضع "غير نشط"
    }
  }

  public void enterDeactivationReason(String reason) {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));

    // انتظر حتى يظهر الـ textarea
    WebElement reasonField = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//textarea[@id='inactvDsc']")
    ));
    reasonField.sendKeys(reason);
  }

  public void clickSaveDeactivation() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    Actions actions = new Actions(driver);


    WebElement saveButton = wait.until(ExpectedConditions.presenceOfElementLocated(
            By.xpath("//button[@type='submit' and contains(@class,'btn-primary')]")
    ));
    wait.until(ExpectedConditions.elementToBeClickable(saveButton));

    actions.moveToElement(saveButton).click().perform();
    System.out.println("✅ تم الضغط على زر حفظ");
  }

  public void verifyCardIsInactive(String cardName) {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));


    // انتظر ظهور شارة "التوقيف" الخاصة بالحالة Inactive
    WebElement inactiveBadge = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//i[@class='fad fa-lock-alt'])[1]")
    ));

    // ✅ Assertion واضحة تقول إن البطاقة اتعملها Inactive
    Assert.assertTrue("🔴 البطاقة لم يتم تعيينها كـ Inactive كما هو متوقع", inactiveBadge.isDisplayed());

    System.out.println("✅ تم تعيين البطاقة كـ Inactive بنجاح: " + cardName);
  }

  public void doubleClickOnCardByName2(String cardName) {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    boolean found = false;
    int maxPages = 20;
    int currentTry = 0;

    while (currentTry < maxPages) {
      currentTry++;

      try {
        closeNotifcationIfVisible();

        WebElement cardRow = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//td[@role='gridcell' and normalize-space()='" + cardName + "']")));

        new Actions(driver).doubleClick(cardRow).perform();
        System.out.println("✅ Found and double-clicked on card: " + cardName);
        found = true;
        break;

      } catch (TimeoutException e) {
        try {
          closeNotifcationIfVisible();

          WebElement currentPage = driver.findElement(By.xpath("//a[contains(@class,'e-currentitem')]"));
          int currentPageNumber = Integer.parseInt(currentPage.getText());
          int nextPageNumber = currentPageNumber + 1;

          List<WebElement> nextPageButtons = driver.findElements(
                  By.xpath("//a[contains(@aria-label,'Page " + nextPageNumber + "')]"));

          if (nextPageButtons.isEmpty()) {
            System.out.println("❌ زر الصفحة التالية غير موجود. توقف.");
            break;
          }

          WebElement nextPageBtn = nextPageButtons.get(0);

          ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPageBtn);
          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageBtn);

          Thread.sleep(2000);

        } catch (Exception ex) {
          System.out.println("❌ Reached last page or couldn't click on page number. Card not found: " + cardName);
          break;
        }
      }
    }

    if (!found) {
      System.out.println("🔍 Card not found in any page: " + cardName);
    }
  }
  public void clickupdButton() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    WebElement plusIcon2 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//i[@class='fas fa-edit faa-shake animated'])[1]")));
    plusIcon2.click();
  }

  public void clearandchange(JSONObject data) {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
    WebElement inputField = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//input[@placeholder='اسم النوع'])[1]")
    ));
    inputField.clear();
    inputField.sendKeys((String) data.get("Type_Name"));
  }


  public void clicksaveCard1() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(400));
    WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//button[@title='حفظ'])[1]")
    ));
    saveBtn.click();
    WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//div[@aria-label='تمت عملية التعديل بنجاح'])[1]")
    ));
    String actualMsg = message.getAttribute("aria-label");
    assertEquals("تمت عملية التعديل بنجاح", actualMsg);
  }

  public void doubleClickOnCardByName3(String cardName) {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    boolean found = false;
    int maxPages = 20;
    int currentTry = 0;

    while (currentTry < maxPages) {
      currentTry++;

      try {
        closeNotifcationIfVisible();

        WebElement cardRow = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//td[@role='gridcell' and normalize-space()='" + cardName + "']")));

        new Actions(driver).doubleClick(cardRow).perform();
        System.out.println("✅ Found and double-clicked on card: " + cardName);
        found = true;
        break;

      } catch (TimeoutException e) {
        try {
          closeNotifcationIfVisible();

          WebElement currentPage = driver.findElement(By.xpath("//a[contains(@class,'e-currentitem')]"));
          int currentPageNumber = Integer.parseInt(currentPage.getText());
          int nextPageNumber = currentPageNumber + 1;

          List<WebElement> nextPageButtons = driver.findElements(
                  By.xpath("//a[contains(@aria-label,'Page " + nextPageNumber + "')]"));

          if (nextPageButtons.isEmpty()) {
            System.out.println("❌ زر الصفحة التالية غير موجود. توقف.");
            break;
          }

          WebElement nextPageBtn = nextPageButtons.get(0);

          ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", nextPageBtn);
          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", nextPageBtn);

          Thread.sleep(2000);

        } catch (Exception ex) {
          System.out.println("❌ Reached last page or couldn't click on page number. Card not found: " + cardName);
          break;
        }
      }
    }

    if (!found) {
      System.out.println("🔍 Card not found in any page: " + cardName);
    }
  }

  public void clickdelButton() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement deleteBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@class='fas fa-trash faa-shake animated'])[1]")));
    deleteBtn.click();
  }

  public void clickconfirmButton() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    WebElement plusIcon4 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//button[contains(text(),'تأكيد')])[1]")));
    plusIcon4.click();
    WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//div[@aria-label='تمت عملية الحذف بنجاح']")
    ));
    String actualMsg = message.getAttribute("aria-label");
    assertEquals("تمت عملية الحذف بنجاح", actualMsg);
  }


  public void closeNotifcationIfVisible() {
    try {
      WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
      WebElement closeBtn = wait.until(ExpectedConditions.elementToBeClickable(
              By.xpath("//button[contains(text(),'تحديد الكل كمقروءة')]")
      ));
      closeBtn.click();
      System.out.println("🟢 تم إغلاق التنبيه.");
    } catch (Exception e) {
      System.out.println("🔵 لا يوجد إشعار ظاهر.");
    }
  }}

